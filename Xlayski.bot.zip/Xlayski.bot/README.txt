 ░█████╗░░█████╗░██╗░░██╗███████╗░░░██████╗░░█████╗░████████╗
 ██╔══██╗██╔══██╗██║░██╔╝██╔════╝░░░██╔══██╗██╔══██╗╚══██╔══╝
 ██║░░╚═╝███████║█████═╝░█████╗░░░░░██████╦╝██║░░██║░░░██║░░░
 ██║░░██╗██╔══██║██╔═██╗░██╔══╝░░░░░██╔══██╗██║░░██║░░░██║░░░
 ╚█████╔╝██║░░██║██║░╚██╗███████╗██╗██████╦╝╚█████╔╝░░░██║░░░
 ░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝╚═╝╚═════╝░░╚════╝░░░░╚═╝░░░
Cake.bot was made by @cake.net
DO NOT SELL THIS CODE.

ONLY WORKS WITH PYTHON VERSION 3.12

StatusChanger-
Add your own custom statuses in the status.txt file.

Cake.bot-
Change "Enter Your User ID" to your discord user id.

SETUP-
Run the setup.py file and wait for it to close automatically.
Once closed you may run cakebot.py or statuschanger.py.