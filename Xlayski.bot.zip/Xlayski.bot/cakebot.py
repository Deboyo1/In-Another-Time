#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝     ╚═════╝ ╚═════╝ ╚══════╝   ╚═╝
#Selfbot Made By Greed / Fazo / Xlayski
#Do not sell this code.
#It's noted you shouldn't add anything other packages to this bot or it will cause a break and glitch.
#Do not add or remove from the code unless you have experience with python.
#For a list of commands please use .help
#If you have questions or concerns about this bot DM @selfdeny or @Selfdecline
#---------------------------------------------------------------------------------------------------#
#Imports
import discord
from discord.ext import commands
import asyncio
import random
import urllib
import aiohttp
import time
import requests
import base64
#---------------------------------------------------------------------------------------------------#
#Addons
t973 = input("[+] Please enter your Token: ")
#---------------------------------------------------------------------------------------------------#
#Command Function: ;
bot = commands.Bot(command_prefix=".", self_bot=True)
bot.remove_command('help')
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝     ╚═════╝ ╚═════╝ ╚══════╝   ╚═╝
#---------------------------------------------------------------------------------------------------#
#LogIn
login = f"""
  ╔════════════════════════════════════════════════════════════════════════════════════╗
  ║                                                                                    ║
  ║ ██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗  ║
  ║ ██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝  ║
  ║ ██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║     ║ 
  ║ ██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║     ║
  ║ ██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║     ║  
  ║ ╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝     ╚═════╝ ╚═════╝ ╚══════╝   ╚═╝     ║
  ║                                                                                    ║
  ╚════════════════════════════════════════════════════════════════════════════════════╝






⠀⠀⠀⠀⠀⠀⠀⠀                             ⣀⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                        ⣬⣾⣮⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀                        ⢠⣠⣴⣿⡿⣿⣧⣤⡀⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀                        ⠨⢿⡷⣾⡿⢳⠿⣿⣶⣿⢖⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                        ⢸⣯⣏⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀     ⠀⠀⠀                       ⠀⠀⣠⣿⡼⣾⣇⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀                       ⣾⢿⣱⠀⠀⠀⠀⣰⣭⣿⣿⣿⣿⣇⢀⠀⠀⠀⣐⣾⣿⠀⠀⠀
                      ⣄⣦⣿⡿⣿⠷⣾⣿⣷⡟⣷⣿⣿⣿⣷⡟⣷⣿⣷⡾⣟⠿⣿⣤⣆⠄
                      ⠙⠻⠿⣿⣏⣿⣷⠿⢿⢟⡏⣿⣿⣿⣟⣿⢟⡿⠷⣿⣻⣿⡿⠿⠋⠈               
⠀⠀⠀                       ⠩⢻⣿⡄⠀⠀⠈⠻⣼⣿⣿⡸⠋⠁⠀⠀⢸⡿⡓⠁⠀⠀⠀
⠀⠀⠀⠀⠀                        ⠙⠀⠀⠀⠀⠀⢿⣿⣿⠃⠀⠀⠀⠀⠘⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                        ⣺⣿⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀                        ⠀⠀⣹⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                        ⠀⢹⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀                        ⠀⠀⣽⣿⣿⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀                        ⠀⢠⣿⢷⢿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀                        ⢠⣿⣿⠋⢟⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀                        ⠀⣀⣿⣿⣫⣆⣮⣛⣿⡅⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀                        ⠀⠸⠿⣿⣿⣿⡄⣿⣿⣿⠿⠮⠆⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀                        ⠀⠀⠸⢿⣽⣝⣽⣽⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀                        ⠀⠙⢻⣿⣿⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                        ⠀⠈⠁

               ╔════════════════════════════════════════════════════════╗
               ║   You're now logged in as {bot.user}. Enjoy Self Bot!  ║
               ║   Made by @selfdeny                                    ║
               ╚════════════════════════════════════════════════════════╝
"""
@bot.event
async def on_ready():
    print(login)
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝     ╚═════╝ ╚═════╝ ╚══════╝   ╚═╝
#---------------------------------------------------------------------------------------------------#
#DM (DMs all users on your friends list) [Usage]: ;dm (message)
@bot.command()
async def dm(message):
    for friend in bot.user.friends:
        try:
            delay = random.randint(5, 30)
            time.sleep(delay)
            await friend.send(message)
        except Exception as e:
            print(f"Failed to send message to {friend}: {e}")
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝     ╚═════╝ ╚═════╝ ╚══════╝   ╚═╝
#---------------------------------------------------------------------------------------------------#
#Stream (Set custom streaming status) [Usage]: ;stream (message)
@bot.command()
async def stream(ctx, *, message):
    await ctx.message.delete()
    await ctx.send(f"```[+]{bot.user} is now streaming {message}```")

    stream_activity = discord.Streaming(
        name=message,
        url="https://www.twitch.tv/x",
    )
    await ctx.bot.change_presence(activity=stream_activity)
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#Game (Set custom gaming status) [Usage]: ;game (message)
@bot.command()
async def game(ctx, *, message):
    await ctx.message.delete()

    game_activity = discord.Game(
        name=message,
    )
    await ctx.bot.change_presence(activity=game_activity)
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#Mimic (Copy a users messages) [Usage]: ;mimic @(user)
#Mimic (Add your own "blacklist" of words you do not want copied)
mimic_task = None
@bot.command()
async def mimic(ctx, user: discord.User, channel=None):
    await ctx.message.delete()
    global mimic_task

    blacklist = [
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "10",
        "11",
        "12",
        "13",
        "child porn",
    ]

    channel = ctx.channel
    last_message_id = None

    async def mimic_loop():
        nonlocal last_message_id
        while True:
            async for message in channel.history(limit=1, oldest_first=False):
                if message.author == user and message.id != last_message_id:
                    contains_blacklisted = any(word in message.content.lower() for word in blacklist)
                    if not contains_blacklisted:
                        await channel.send(message.content)
                    last_message_id = message.id
                    break

    mimic_task = bot.loop.create_task(mimic_loop())
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#Stop Mimic (Stop mimicking a user) [Usage]: ;stopmimic
@bot.command()
async def mimicstop(ctx):
    await ctx.message.delete()
    global mimic_task
    if mimic_task:
        mimic_task.cancel()
        mimic_task = None
        await ctx.send("```[-] mimic stopped | made by greed.```")
    else:
        await ctx.send("```[-] you are not mimicking anyone at the moment.```")
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#Tweet (Send a custom fake tweet gif of a user) [Usage]: ;tweet @(user) (message)
@bot.command()
async def tweet(ctx, user: discord.User = None, *, message: str = None):
    await ctx.message.delete()
    if user is None or message is None:
        await ctx.send(f'[ERROR]: Invalid input! Command: {bot.command_prefix}tweet <@user> <message>')
        return

    username = user.name
    avatar_url = user.avatar_url

    async with aiohttp.ClientSession() as cs:
        async with cs.get(
                f"https://nekobot.xyz/api/imagegen?type=tweet&username={urllib.parse.quote(username)}&text.txt={message}&avatar={avatar_url}") as r:
            res = await r.json()
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(str(res['message'])) as resp:
                        image = await resp.read()
                with io.BytesIO(image) as file:
                    await ctx.send(file=discord.File(file, f"av_tweet.png"))
            except:
                await ctx.send(res['message'])
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#React (Auto react to your own messages with an emoji) [Usage]: ;react
tracked_users = {}
@bot.command()
async def react(ctx, user: discord.Member, emoji: str):
    await ctx.message.delete()
    tracked_users[user.id] = emoji
    await ctx.send(
        f"```Now reacting to {user.mention}'s messages with {emoji}.```",
        delet_after = 4
    )

@bot.event
async def on_message(message):
    # Ignore bots (including itself) to avoid infinite loops
    if message.author.bot:
        return

    # If the message author is in our tracked list, react with the stored emoji
    if message.author.id in tracked_users:
        emoji = tracked_users[message.author.id]
        try:
            await message.add_reaction(emoji)
        except discord.HTTPException:
            # If the emoji is invalid or we lack permission, we catch the error
            pass

    # Ensure other commands still work
    await bot.process_commands(message)
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#React Stop (Stop reacting to your own messages) [Usage]: ;reactstop
@bot.command()
async def reactstop(ctx, user: discord.Member):
    await ctx.message.delete
    if user.id in tracked_users:
        del tracked_users[user.id]
        await ctx.send(
            f"```[+]No longer reacting to {user.mention}```",
            delete_after = 4
        )
    else:
        await ctx.send(
            f"```[+]Error, {user.mention} was not being reacted to```",
        )
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#Clear (Delete your own messages automatically) [Usage]: ;clear (number)
@bot.command()
async def clear(ctx, amount: int):
    await ctx.message.delete()
    time.sleep(1)
    deleted_count = 0
    deleted_messages = []
    async for message in ctx.channel.history(limit=None):
        if message.author == ctx.author or deleted_count == amount:
            try:
                await message.delete()
                deleted_count += 1
                deleted_messages.append(message.content)
                print(f"{deleted_count} message(s) deleted from {ctx.author} in {ctx.channel}: {message.content}")
                await asyncio.sleep(3)
            except:
                pass
        if deleted_count >= amount:
            break

    deleted_msgs_str = "\n".join(deleted_messages)
    await ctx.send(f"```[+] deleted {deleted_count} messages.```")

    await asyncio.sleep(2)
    await ctx.message.delete()


@bot.command()
async def fastclear(ctx, amount: int):
    await ctx.message.delete()
    time.sleep(1)
    deleted_count = 0
    deleted_messages = []
    async for message in ctx.channel.history(limit=None):
        if message.author == ctx.author or deleted_count == amount:
            try:
                await message.delete()
                deleted_count += 1
                deleted_messages.append(message.content)
                print(f"{deleted_count} message(s) deleted from {ctx.author} in {ctx.channel}: {message.content}")
                await asyncio.sleep(0.1)
            except:
                pass
        if deleted_count >= amount:
            break

    deleted_msgs_str = "\n".join(deleted_messages)
    await ctx.send(f"```[+] deleted {deleted_count} messages.```")

    await asyncio.sleep(2)
    await ctx.message.delete()
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#AFK (Announce you are afk with/without a status [Usage]: ;afk / ;afk (message)
@bot.command()
async def afk(ctx, *, message: str = None):
    await ctx.message.delete()
    if message is None:
        await ctx.send(f"```[+]{bot.user} Is now afk.```")

        url = "https://discord.com/api/v8/users/@me/settings"

        header = {
            "authorization": t973
        }

        jsonData = {
            "status": "idle"
        }
        request = requests.patch(url, headers=header, json=jsonData)
        return request
    
    else:
        await ctx.send(f"```[+]{bot.user} Is now afk. Status: {message}```")

        url = "https://discord.com/api/v8/users/@me/settings"

        header = {
            "authorization": t973
        }

        jsonData = {
            "status": "idle",
            "custom_status": {
                "text": message,
            }
        }
        request = requests.patch(url, headers=header, json=jsonData)
        return request

#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#Search (Quick search something on Google) [Usage]: ;search (message)
@bot.command()
async def search(ctx, message):
    url = f"https://images.google.com/search?q={message}"
    await ctx.message.delete()
    await ctx.send(url)
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#Spam (Spam a custom message) [Usage]: ;spam (message)
#Spam (MAY GET YOU MUTED OR RATE LIMITED)
spam_task = None
@bot.command()
async def spam(ctx, *, message: str = None):
    await ctx.message.delete()

    global spam_task
    last_message_id = None

    async def spam_loop():
        nonlocal last_message_id
        while True:
            for _ in range(35):
                await ctx.send(message)
                break

    spam_task = bot.loop.create_task(spam_loop())

@bot.command()
async def spamstop(ctx):
    await ctx.message.delete()
    global spam_task
    if spam_task:
        spam_task.cancel()
        spam_task = None
        await ctx.send("```[+] Spam disabled.```")
    else:
        await ctx.send("```[+] Spam is already disabled.```")

#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
nuke_task = None
@bot.command()
async def nuke(ctx, *, message: str = None):
    await ctx.message.delete()

    global nuke_task
    last_message_id = None

    async def nuke_loop():
        nonlocal last_message_id
    for channel in ctx.guild.channels:
        await channel.delete()

        while True:
            for _ in range(35):
                channel = await ctx.guild.create_text_channel(name=f"{message}")
                await ctx.guild.create_text_channel(name=f"{message}")
                await channel.send("@everyone @here discord.gg/exorcistpirates")
                break

    nuke_task = bot.loop.create_task(nuke_loop())

@bot.command()
async def nukestop(ctx):
    await ctx.message.delete()
    global nuke_task
    if nuke_task:
        nuke_task.cancel()
        nuke_task = None
        await ctx.send("```[+] Nuke disabled | Blow these niggas up.```")
    else:
        await ctx.send("```[+] Nuke is already disabled.```")
    


@bot.command()
async def kall(ctx):
    await ctx.message.delete()
    for member in ctx.guild.members:

        if member == bot.user:
            continue

        try:
            await member.kick()
        except discord.Forbidden:
            print(f"{member.name} has FAILED to be kicked from {ctx.guild.name}")
        else:
            return False
# ---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#Gif (Quickly send a gif) [Usage]: ;gif (category)
#Gif (Use ";gif help" if confused.)
@bot.command()
async def gif(ctx, *, message: str = None):
    rofl = [
    "https://tenor.com/view/rofl-emoji-man-rofl-laughing-emoji-rolling-on-the-floor-laughing-emoji-laughing-gif-18202826402110873263",
    "https://tenor.com/view/laughing-hysterically-gif-18079239",
    "https://tenor.com/view/lmao-haha-laughing-happy-emoji-gif-15583622",
    "https://tenor.com/view/happy-laughing-lol-lmao-funny-gif-17864758",
    "https://tenor.com/view/laughing-giggle-joy-happy-emoji-gif-16065126",
    ]
    no = ["https://tenor.com/view/nonono-gif-1085638213599558756",
    "https://tenor.com/view/nuhuh-emoticon-emoticon-gif-5008343868045376139",
    "https://tenor.com/view/pull-up-gif-8601062262686497425",
    "https://tenor.com/view/big-thumbs-down-emoticon-emoticon-gif-8425256358899761878",
    "https://tenor.com/view/sad-emote-emoji-thumbs-down-mid-gif-26466326",
    "https://tenor.com/view/vanjuranegando-gif-27556467",
    ]
    nerd = [
    "https://tenor.com/view/nerd-emoji-nerdge-gif-23738139",
    "https://tenor.com/view/nerd-nerd-emoji-meme-speech-bubble-bubble-gif-25115885",
    "https://tenor.com/view/nerd-nerdy-nerds-nerd-emoji-gif-25380417",
    "https://tenor.com/view/uh-oh-gif-13596626063477654102",
    "https://tenor.com/view/happiness-love-happy-face-patrick-star-spongebob-gif-8985902394226722705",
    "https://tenor.com/view/nerd-emoji-nerd-meme-radar-gif-26497624",
    "https://tenor.com/view/emoji-gif-15839856305382660441",
    "https://tenor.com/view/contendo-gif-14873122474423590693",
    "https://tenor.com/view/benitwt-gif-22390628",
    "https://tenor.com/view/nerd-gif-26834349",
    "https://tenor.com/view/nerd-cat-meme-lol-nerd-emoji-gif-27126052",
    "https://tenor.com/view/nerd-skull-emoji-merged-made-by-king-gif-13914708873730542669",
    "https://tenor.com/view/nerdy-panda-joypixels-nerdy-panda-im-a-nerd-gif-17142718",
    "https://tenor.com/view/yemicus-gif-16520545057814691339",
    "https://tenor.com/view/nerd-gif-22822417",
    "https://tenor.com/view/cat-nerd-nerd-emoji-kitten-um-actually-gif-18197072183915678800",
    "https://tenor.com/view/nerdy-dog-joypixels-nerdy-dog-im-a-nerd-gif-17135041",
    "https://tenor.com/view/booboo-gif-24794382",
    ]

    shh = [
        "https://tenor.com/view/shushing-face-joypixels-secret-quiet-behave-gif-17554216",
        "https://tenor.com/view/emoji-emojis-emoticon-mood-quiet-gif-16106944",
        "https://tenor.com/view/emoji-shut-your-mouth-damn-it-what-gif-16542382",
        "https://tenor.com/view/shushing-face-joypixels-secret-quiet-behave-gif-17554216",
        "https://tenor.com/view/quiet-cat-joypixels-behave-remain-silence-gif-17135349",
        "https://tenor.com/view/emoji-hush-shut-up-bbhb-ballbags-gif-11780038",
    ]
    help = "```[+] Categories: rofl, no, nerd, shh```"

    if message == "rofl":
        await ctx.send(random.choice(rofl))

    if message == "no":
        await ctx.send(random.choice(no))

    if message == "nerd":
        await ctx.send(random.choice(nerd))

    if message == "shh":
        await ctx.send(random.choice(shh))
        
    if message is None:
        await ctx.send (f"```[ERROR]: Invalid input! Command: {bot.command_prefix}gif <category> | Type {bot.command_prefix}gif help for more info.```")
        return
    if message == "help":
        await ctx.send(help)
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#Simple Calculator (Calculate 2 numbers quickly) [Usage]: ;add/;sub/;multi/;div (FirstNumber) (SecondNumber)
@bot.command()
async def add(ctx,a:int,b:int):
    await ctx.send(f"```[+]{a} + {b} = {a+b}```") #Adds A and B

@bot.command()
async def sub(ctx,a:int,b:int):
    await ctx.send(f"```[+]{a} - {b} = {a-b}```") #Subtracts A and B

@bot.command()
async def multi(ctx,a:int,b:int):
    await ctx.send(f"```[+]{a} * {b} = {a*b}```") #Multplies A and B

@bot.command()
async def div(ctx,a:int,b:int):
    await ctx.send(f"```[+]{a} / {b} = {a/b}```") #Divides A and B
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#Status (Change your custom status quickly) [Usage]: ;status (message)
@bot.command()
async def status(ctx, *, message):
    await ctx.message.delete()

    custom_status = message
    url = "https://discord.com/api/v8/users/@me/settings"

    header = {
        "authorization": t973
    }

    jsonData = {
        "custom_status": {
            "text": custom_status
        }
    }
    request = requests.patch(url, headers=header, json=jsonData)
    return request
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#Appear (Quickly appear online) [Usage]: ;online
@bot.command()
async def online(ctx):
    await ctx.message.delete()

    url = "https://discord.com/api/v8/users/@me/settings"

    header = {
        "authorization": t973
    }

    jsonData = {
        "status": "online",
        }
    request = requests.patch(url, headers=header, json=jsonData)
    return request
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#Offline (Quickly appear offline) [Usage]: ;offline
@bot.command()
async def offline(ctx):
    await ctx.message.delete()

    url = "https://discord.com/api/v8/users/@me/settings"

    header = {
        "authorization": t973
    }

    jsonData = {
        "status": "invisible",
        }
    request = requests.patch(url, headers=header, json=jsonData)
    return request
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#DnD (Quickly appear as Do not Disturb) [Usage]: ;dnd
@bot.command()
async def dnd(ctx):
    await ctx.message.delete()

    url = "https://discord.com/api/v8/users/@me/settings"

    header = {
        "authorization": t973
    }

    jsonData = {
        "status": "dnd",
        }
    request = requests.patch(url, headers=header, json=jsonData)
    return request
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#idle (Quickly appear as idle) [Usage]: ;idle
@bot.command()
async def idle(ctx):
    await ctx.message.delete()

    url = "https://discord.com/api/v8/users/@me/settings"

    header = {
        "authorization": t973
    }

    jsonData = {
        "status": "idle",
        }
    request = requests.patch(url, headers=header, json=jsonData)
    return request
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
#Typing (Begin fake typing in selected channel) [Usage]: typing <amount of time>
typing_active = {}

@bot.command()
async def typing(ctx, time: str, channel: discord.TextChannel = None):
    
    if channel is None:
        channel = ctx.channel

    total_seconds = 0


    try:
        if time.endswith('s'):
            total_seconds = int(time[:-1]) 
        elif time.endswith('m'):
            total_seconds = int(time[:-1]) * 60  
        elif time.endswith('h'):
            total_seconds = int(time[:-1]) * 3600  
        else:
            total_seconds = int(time)  
    except ValueError:
        await ctx.send("```[+]Error! Use a valid time format: (5s, 2m, 1h).```", delete_after = 5)
        return

   
    typing_active[channel.id] = True

    try:
        async with channel.typing():
            await ctx.send(f"```[+]Triggered typing for {total_seconds}```", delete_after = 5)
            await asyncio.sleep(total_seconds)  
    except Exception as e:
        await ctx.send("```[+]Failed to trigger typing```", delete_after = 5)
    finally:
        typing_active.pop(channel.id, None)
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
@bot.command()
async def typingstop(ctx, channel: discord.TextChannel = None):

    
    if channel is None:
        channel = ctx.channel

    if channel.id in typing_active:
        typing_active.pop(channel.id)  
        await ctx.send(f"```[+]Stopped typing in {channel.name}.```", delete_after = 5)
    else:
        await ctx.send(f"```[+]Error! Not typing in this channel.```", delete_after = 5)
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
@bot.command(name="banner")
async def userbanner(ctx, user: discord.User):
    headers = {
        "Authorization": bot.http.token,
        "Content-Type": "application/json"
    }
    
    url = f"https://discord.com/api/v9/users/{user.id}/profile"
    
    try:
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            banner_hash = data.get("user", {}).get("banner")
            
            if banner_hash:
                banner_format = "gif" if banner_hash.startswith("a_") else "png"
                banner_url = f"https://cdn.discordapp.com/banners/{user.id}/{banner_hash}.{banner_format}?size=1024"
                await ctx.send(f"```{user.display_name}'s banner:``` [Desire.Cult]({banner_url})")
            else:
                await ctx.send(f"```{user.mention} does not have a banner set.```")
        else:
            await ctx.send(f"Failed to retrieve banner: {response.status_code} - {response.text}")
    
    except Exception as e:
        await ctx.send(f"An error occurred: {e}") 
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
@bot.command(aliases=['av', 'pfp'])
async def avatar(ctx, user: discord.Member = None):
    if user is None:
        user = ctx.author

    avatar_url = str(user.avatar_url_as(format='gif' if user.is_avatar_animated() else 'png'))

    await ctx.send(f"```{user.name}'s pfp```[Desire.Cult]({avatar_url})")
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
autoreply_tasks = {}
autoreplies = [
"# bitch made faggot",
"# twink ass nigga",
"# ur a shitter nigga",
"# shut the fuck up",
"# your my son LOL",
"# your not stepping to exorcist",
"# greed owns your limbs",
"# your dog shit nigga",
"# show me a penny peon",
"# desire owns your limbs peasent",
"# faggot ass skid",
"# keep up son",
"# ur weak",
"# come die in .gg/exorcistpirates",
"# im above you",
"# you smell like donkey dick take a shower peon",
"# greed just smacked your under nipple",
"# ur corny",
"# im a god compared to you peon",
"# your so ass WTF",
"# i'm above you peon",
"# worthless peasent",
"# stay outta my domain dork",










]
@bot.command()
async def autoreply(ctx, user: discord.User):
    channel_id = ctx.channel.id

    await ctx.send(f"```Autoreply for {user.mention} has started.```")

    async def send_autoreply(message):
        while True:  
            try:
                random_reply = random.choice(autoreplies)
                await message.reply(random_reply)
                print(f"Successfully replied to {user.name}")
                break  
            except discord.errors.HTTPException as e:
                if e.status == 429:  
                    try:
                        response_data = await e.response.json()
                        retry_after = response_data.get('retry_after', 1)
                    except:
                        retry_after = 1 
                    print(f"Rate limited please holt, waiting {retry_after} seconds...")
                    await asyncio.sleep(retry_after)
                else:
                    print(f"HTTP Error: {e}, retrying...")
                    await asyncio.sleep(1)
            except Exception as e:
                print(f"Error sending message: {e}, retrying...")
                await asyncio.sleep(1)

    async def reply_loop():
        def check(m):
            return m.author == user and m.channel == ctx.channel

        while True:
            try:
                message = await bot.wait_for('message', check=check)
                asyncio.create_task(send_autoreply(message))
                await asyncio.sleep(0.1)  
            except Exception as e:
                print(f"Error in reply loop: {e}")
                await asyncio.sleep(1)
                continue


    task = bot.loop.create_task(reply_loop())
    autoreply_tasks[(user.id, channel_id)] = task
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
@bot.command()
async def autoreplyoff(ctx):
    channel_id = ctx.channel.id
    tasks_to_stop = [key for key in autoreply_tasks.keys() if key[1] == channel_id]
    
    if tasks_to_stop:
        for user_id in tasks_to_stop:
            task = autoreply_tasks.pop(user_id)
            task.cancel()
        await ctx.send("```[+]Autoreply has been stopped.```", delete_after = 5)
    else:
        await ctx.send("```[+]Error! Not replying to any users.```", delete_after = 5)
#---------------------------------------------------------------------------------------------------#
#██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
#██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
#██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
#██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
#██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
#╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
#---------------------------------------------------------------------------------------------------#
help_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
Use ;help <command> for more info / Dm @DesireGreed for help.
-------------------------------------------------------------
Commands:

[1] Mimic               [11] Afk                [13] Av
[2] MimicStop           [12] Stream             [13] Banner
[3] React               [13] Game               [13] Tweet
[4] ReactStop           [13] Status             [14] AutoReply   ⠀⠀                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                ⣬⣾⣮⠄ ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀                ⢠⣠⣴⣿⡿⣿⣧⣤⡀⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀                ⠨⢿⡷⣾⡿⢳⠿⣿⣶⣿⢖⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                ⢸⣯⣏⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀    ⠀⠀⠀                ⠀ ⣠⣿⡼⣾⣇⡀⠀⠀⠀⠀⠀⣀⠄⠀⠀⠀
⠀⠀               ⣾⢿⣱⠀⠀⠀⠀⣰⣭⣿⣿⣿⣿⣇⢀⠀⠀⠀⣐⣾⣿⠀⠀⠀
               ⣄⣦⣿⡿⣿⠷⣾⣿⣷⡟⣷⣿⣿⣿⣷⡟⣷⣿⣷⡾⣟⠿⣿⣤⣆⠄
               ⠙⠻⠿⣿⣏⣿⣷⠿⢿⢟⡏⣿⣿⣿⣟⣿⢟⡿⠷⣿⣻⣿⡿⠿⠋⠈               
⠀⠀⠀               ⠩⢻⣿⡄⠀⠀⠈⠻⣼⣿⣿⡸⠋⠁⠀⠀⢸⡿⡓⠁⠀⠀⠀
⠀⠀⠀⠀⠀                ⠙⠀⠀⠀⠀⠀⢿⣿⣿⠃⠀⠀⠀⠀⠘⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀ - DESIRE CULT -        ⣺⣿⣿⡆⠀⠀⠀     - DESIRE CULT - ⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀                  ⣹⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                 ⢹⣿⣿⠇⠀ ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀                  ⣽⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀                 ⢠⣿⢷⢿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀                ⢠⣿⣿⠋⢟⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀                 ⣀⣿⣿⣫⣆⣮⣛⣿⡅⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀                 ⠸⠿⣿⣿⣿⡄⣿⣿⣿⠿⠮⠆⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀                  ⠸⢿⣽⣝⣽⣽⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀                 ⠙⢻⣿⣿⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀                        ⠀⠈⠁         
[5] Clear               [15] Typing             [25] AutoReplyOff
[6] FastClear           [16] TypingStop         [26] IpLookUp
[7] Online              [17] Gif                [27] SpamStop
[8] DnD                 [18] Dm                 [28] Kill
[9] Idle                [19] Nuke               [29] Coming soon!
[10] Offline            [20] Spam               [30] Coming Soon!


------------------------------------------------------------- 
 ```"""
# Took At least 3 Hours... (DONT SKID MY SHIT)
mimic_menu = f"""``` 
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[1] Mimic:

Copies the selected users messages (DOES NOT WORK WITH IMAGES!)

Use Example: ;mimic @<user> (Don't over due it) - Desire Greed -
-------------------------------------------------------------
```"""

mimicstop_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝ ██   ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[2] Mimic Stop:

Stops copying other users messages.

Use Example: ;mimicstop - Desire Greed -
-------------------------------------------------------------
```"""

React_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[3] React:

React to a selected users messages with any selected emoji.

Use Example: ;react @<user> <emoji> - Desire Greed -
-------------------------------------------------------------
```"""

ReactStop_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[4] React Stop:

Stops reacting to a users messages.

Use Example: ;reactstop @<user> - Desire Greed -
-------------------------------------------------------------
```"""

Clear_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[5] Clear:

Automatically delete your messages.

Use Example: ;clear <amount> - Desire Greed -
-------------------------------------------------------------
```"""

FastClear_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[6] FastClear:

⚠︎ RATE LIMIT WARNING ⚠︎

Automatically deletes your messages quickly.

Use Example: ;reactstop @<user> - Desire Greed -
-------------------------------------------------------------
```"""

online_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[7] Online:

Set your appearance to online.

Use Example: ;online - Desire Greed -
-------------------------------------------------------------
```"""

dnd_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[8] dnd:

Set your appearance to Do not Disturb.

Use Example: ;dnd - Desire Greed -
-------------------------------------------------------------
```"""

idle_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[9] idle:

Set your appearance to idle.

Use Example: ;idle - Desire Greed -
-------------------------------------------------------------
```"""

offline_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[10] offline:

⚠︎ RATE LIMIT WARNING ⚠︎

Set your appearance to invisble.

Use Example: ;offline - Desire Greed -
-------------------------------------------------------------
```"""

spam_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[20] Spam:

⚠︎ RATE LIMIT WARNING ⚠︎

Automatically spam selected message.

Use Example: ;spam <message> - Desire Greed -
-------------------------------------------------------------
```"""

nuke_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[19] Nuke:

⚠︎ RATE LIMIT WARNING ⚠︎

Automatically nuke a server using a selected message.

Use Example: ;nuke <message> - Desire Greed -
-------------------------------------------------------------
```"""

Dm_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[18] Dm:

⚠︎ RATE LIMIT WARNING ⚠︎

Automatically Dm your friendslist with a selected message.

Use Example: ;Dm <message> - Desire Greed -
-------------------------------------------------------------
```"""

gif_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[17] Gif:

Quickly send a preset gif.

Use Example: ;gif <category>

Use ;gif help for more information - Desire Greed -
-------------------------------------------------------------
```"""

typing_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[15] Typing:

Begin fake typing in a selected channel.

Use Example: ;typing <amount(s/m/h)> - Desire Greed -
-------------------------------------------------------------
```"""

typingstop_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[16] TypingStop:

Stop fake typing in selected channel.

Use Example: ;typingstop - Desire Greed -
-------------------------------------------------------------
```"""

status_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[14] Status:

Set your custom status to a selected message.

Use Example: ;status <message> - Desire Greed -
-------------------------------------------------------------
```"""

game_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[13] Game:

Set a custom gaming presence.

Use Example: ;game <message> - Desire Greed -
-------------------------------------------------------------
```"""

stream_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[12] Stream:

Set a custom streaming status.

Use Example: ;stream <message> - Desire Greed -
-------------------------------------------------------------
```"""

afk_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[11] Afk:

Set an afk status.

Use Example: ;afk / ;afk <message> - Desire Greed -
-------------------------------------------------------------
```"""

av_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[21] Av:

Get a selected users avatar.

Use Example: ;av @<user> - Desire Greed -
-------------------------------------------------------------
```"""

banner_menu = f"""```

-------------------------------------------------------------
[22] Banner:

Get a selected users banner.

Use Example: ;banner @<user> - Desire Greed -
-------------------------------------------------------------
```"""

autoreply_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[24] AutoReply:

Automatically reply to a selected user with preset messages.

Use Example: ;autoreply @<user> - Desire Greed -
-------------------------------------------------------------
```"""

autoreplyoff_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[25] AutoReply Off:

Stop automatically replying to a users messages.

Use Example: ;autreplyoff - Desire Greed -
-------------------------------------------------------------
```"""

iplookup_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[26] IpLookUp:

Quickly get information on an ip.

Use Example: ;iplookup / ;ip (Obv Fake!) - Desire Greed -
-------------------------------------------------------------
```"""

spamstop_menu = f"""```
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗   ██╗██╗     ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝
-------------------------------------------------------------
[26] SpamStop:

Stop spamming a message.

Use Example: ;spamstop - Desire Greed -
-------------------------------------------------------------
```"""



@bot.command()
async def help(ctx, message: str = None):
    await ctx.message.delete()
    if message is None:
        await ctx.send(help_menu,
        delete_after = 10
        )
    if message == "mimic":
        await ctx.send(mimic_menu,
        delete_after = 10
        )
    if message == "mimicstop":
        await ctx.send(mimicstop_menu,
        delete_after = 10
        )
    if message == "av":
        await ctx.send(av_menu,
        delete_after = 10
        )
    if message == "banner":
        await ctx.send(banner_menu,
        delete_after = 10
        )        
    if message == "afk":
        await ctx.send(afk_menu,
        delete_after = 10
        )
    if message == "stream":
        await ctx.send(stream_menu,
        delete_after = 10
        )
    if message == "game":
        await ctx.send(game_menu,
        delete_after = 10
        )
    if message == "status":
        await ctx.send(status_menu,
        delete_after = 10
        )
    if message == "typing":
        await ctx.send(typing_menu,
        delete_after = 10
        )
    if message == "typingstop":
        await ctx.send(typingstop_menu,
        delete_after = 10
        )
    if message == "gif":
        await ctx.send(gif_menu,
        delete_after = 10
        )
    if message == "dm":
        await ctx.send(Dm_menu,
        delete_after = 10
        )
    if message == "spam":
        await ctx.send(spam_menu,
        delete_after = 10
        )
    if message == "nuke":
        await ctx.send(nuke_menu,
        delete_after = 10
        )
    if message == "online":
        await ctx.send(online_menu,
        delete_after = 10
        )
    if message == "idle":
        await ctx.send(idle_menu,
        delete_after = 10
        )
    if message == "dnd":
        await ctx.send(dnd_menu,
        delete_after = 10
        )
    if message == "offline":
        await ctx.send(offline_menu,
        delete_after = 10
        )
    if message == "fastclear":
        await ctx.send(FastClear_menu,
        delete_after = 10
        )
    if message == "clear":
        await ctx.send(Clear_menu,
        delete_after = 10
        )
    if message == "react":
        await ctx.send(React_menu,
        delete_after = 10
        )
    if message == "reactstop":
        await ctx.send(ReactStop_menu,
        delete_after = 10
        )
    if message == "mimic":
        await ctx.send(mimic_menu,
        delete_after = 10
        )
    if message == "mimicstop":
        await ctx.send(mimicstop_menu,
        delete_after = 10
        )
    if message == "autoreply":
        await ctx.send(autoreply_menu,
        delete_after = 10
        )
    if message == "autoreplyoff":
        await ctx.send(autoreplyoff_menu,
        delete_after = 10
        )
    if message == "iplookup":
        await ctx.send(iplookup_menu,
        delete_after = 10
        )
    if message == "spamstop":
        await ctx.send(spamstop_menu,
        delete_after = 10
        )
        





website = "redtiger.shop"

@bot.command(aliases=["ip", "ipsearch"])
async def iplookup(ctx, *, message):
    await ctx.message.delete()
    try:
        ip = message

        try:
            response = requests.get(f"https://{website}/api/ip/ip={ip}")
            api = response.json()

            ip = api.get('ip')
            status = api.get('status')
            country = api.get('country')
            country_code = api.get('country_code')
            region = api.get('region')
            region_code = api.get('region_code')
            zip = api.get('zip')
            city = api.get('city')
            latitude = api.get('latitude')
            longitude = api.get('longitude')
            timezone = api.get('timezone')
            isp = api.get('isp')
            org = api.get('org')
            as_host = api.get('as')

        except:
            response = requests.get(f"http://ip-api.com/json/{ip}")
            api = response.json()

            status = "Valid" if api.get('status') == "success" else "Scamming Americans"
            country = api.get('country', "India")
            country_code = api.get('countryCode', "+91")
            region = api.get('regionName', "Delhi")
            region_code = api.get('region', "+91-11")
            zip = api.get('zip', "110001")
            city = api.get('city', "Taj Pul")
            latitude = api.get('lat', "27.17 degrees North | 27.173891° N")
            longitude = api.get('lon', "78.04 degrees East  | 78.042068° E")
            timezone = api.get('timezone', "UTC")
            isp = api.get('isp', "Bharti Airtel")
            org = api.get('org', "CaptainCurryCock.ORG")
            as_host = api.get('as', "FaJid-XL3VcL")

        info = (f"""```  
██████╗ ███████╗███████╗██╗██████╗ ███████╗     ██████╗██╗  ██╗██╗      ████████╗
██╔══██╗██╔════╝██╔════╝██║██╔══██╗██╔════╝    ██╔════╝██║   ██║██║     ╚══██╔══╝
██║  ██║█████╗  ███████╗██║██████╔╝█████╗      ██║     ██║   ██║██║        ██║   
██║  ██║██╔══╝  ╚════██║██║██╔══██╗██╔══╝      ██║     ██║   ██║██║        ██║   
██████╔╝███████╗███████║██║██║  ██║███████╗    ╚██████╗╚██████╔╝███████╗   ██║   
╚═════╝ ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝╚══════╝      ╚═════╝ ╚═════╝ ╚══════╝  ╚═╝ 
    -------------------------------------------------------------
                    [+]{message}[+]
        [+] Status     : {status}
        [+] Country    : {country} {country_code}
        [+] Region     : {region} {region_code}
        [+] Zip        : {zip}
        [+] City       : {city}
        [+] Latitude   : {latitude}
        [+] Longitude  : {longitude}
        [+] Timezone   : {timezone}
        [+] Isp        : {isp}
        [+] Org        : {org}
        [+] As         : {as_host}
    -------------------------------------------------------------
        ```""")
        await ctx.send(f"```[+] Processing information for {message}```", delete_after = 12)
        await asyncio.sleep(1)
        await ctx.send(info, delete_after = 10)
    except Exception as e:
        print("error")




@bot.command()
async def edit(ctx):
    messages = await ctx.channel.history(limit=1).flatten()

    for message in messages:
        if message.author.id == ctx.author.id:
            await ctx.message.edit(content=f"{message.content}  ")




edit_task = None
@bot.command()
async def autoedit(ctx):

    global edit_task

    async def edit_loop():
        while True:
            messages = await ctx.channel.history(limit=1).flatten()            
            for message in messages:
                if message == message:
                    await ctx.message.edit(content=f"{message.content}  ")

    edit_task = bot.loop.create_task(edit_loop())


@bot.command()
async def autoeditstop(ctx):
    await ctx.message.delete()
    global edit_task
    if edit_task:
        edit_task.cancel()
        edit_task = None
        await ctx.send("```[+] Auto editing disabled.```")
    else:
        await ctx.send("```[+] Auto editing is already disabled.```")





presstext = [
    "# stop talking",
    "# run dork",
    "# your",
    "# my son",
    "# faggot ass peon",
    "# getting bitched by greed",
    "# poor",
    "# ass dork",
    "# LOL",
    "# nigga u disgusting as fuck",
    "# dumbass cuck has no money",
    "# you be arm wrestling with venus flytraps",
    "# your weak LOL",
    "# desire cults",
    "# owns you",
    "# your not worthy",
    "# useless dork",
    "# Your dog shit",
    "# i'll rip your fucking stomach open",
    "# piss poor ass nigga",
    "# whos daddy little nigga",
    "# your ass",
    "# You got a convertible cheese that you keep in your closet incase you need a spare tire",
    "# THIS NIGGA SLUMP GREAT GRANDADDY GOT SHOT IN THE ARMPIT BY A PANSEXUAL SPOON NIGGA",
    "# Yo aunty got a pool full of bear piss in her backyard that she throw a question mark in everyday to stop the sun from going down",
    "# Yo uncle had lots of cheddar cheese on his nose and that’s why he got robbed by hella rabbits with his mom shaking a pepper shaker in the background",
    "# that nigga sun owns you,",
    "# jvc faggot,",
    "# this yo angry ass https://media.discordapp.net/attachments/1015425092802584576/1085796290807476235/togif.gif?ex=67645758&is=676305d8&hm=29f46291b1bf2f4540b9c6a6d3da5e4ab817f835a2dc4ca4ce5d6a6f8b2d2902&",
    "# WYD SON https://cdn.discordapp.com/attachments/1292181560598204580/1309546483619725414/dd03ea60122c479592479238803b4e3e_464_464.png?ex=6741f9b3&is=6740a833&hm=6b19911bbc90e419d26e726be87f645f2c29b16d0544f18aa26a3a2ee8066ca9&",
    "# YOU DIED BY SLUMP BTW,",
    "# Nigga yo grandma was doing the chacha with a ladybug and got sent in a coffin by the undertaker underground sending her for 47 years",
    "# YOU DIED BY GREED",
    "# yo ass got a dolphin diving overbite like cerics",
    "# This nigga performed at the superbowl nigga was performing a porn video with Eminem holding a baseball bat giving backshots to a lifeguard popping pink percs with a princess with Parkinsons",
    "# Nigga yo aunty got a tattoo on her neck that says 'young man' cuz once upon a time that bitch was yo uncle",
    "# Nigga you tried to take a shit but a random ghost smacked you on the back of the head 'hell no' nigga can’t shit properly", 
    "# yo ass got slap boxxed by slumps great grandaddy using a pansexual safety pin",
    "# this nigga look like wolve2k8 lil ugly ass",
    "# yo ass look like ace if he was a pansexual hermitcrab LOL",
    "# YO ASS TRIED TO USE A RELL SEAS PACK BIBLE LMAOAOAO https://cdn.discordapp.com/attachments/1306402930533859398/1318398531928592404/Screenshot_2024-12-15_023517.png?ex=67622dd0&is=6760dc50&hm=b10d0450a292fc0dacf3ce12c6861a4abd35e645d756978659cd8849c2e87e2b&",
    "# Yo water system don’t even work, so when you pull it out, just a bunch of fire with a fire breathing dildo munching on stop signs tell you to up a blaze set",
    "# PUT IT ON GOD https://cdn.discordapp.com/attachments/1292181560598204580/1309554609467031632/Screenshot_2024-08-07_024247.png?ex=67420145&is=6740afc5&hm=88122e71e83e4624a4d2349dd01d4c7b908a51646efb18c32e19667f4ec45ba5&,",
    "# exorcist pirates owns you btw,",
    "# Nigga you trained yo dog to land a backflip off a plane with a parachute so when an avalanche comes, the door shuts on George Washington’s collared t-shirt",
    "# Nigga yo uncle so buff, when he flexes, he can shoot lasers out his nipples with a painting of Obama telling him to watch his tone, 'WATCH YO TONE!' Bitch ass nigga",
    "# YOU DIED BY DESIRE BTW",
    "# Your ass look like wifiskeleton https://cdn.discordapp.com/attachments/1292181560598204580/1309558157420400640/ab67616d00001e0229871c4130b6b23e2296806b.jpg?ex=67420493&is=6740b313&hm=6e380ea0100f4a2f0605ab55482d2a76124c8df881cdf25a78c8aa85e2e3fbd2&",
    "# Nigga yo grandma put you in the washing machine by accident with bleach and made you albino bitch ass nigga",
    "# GREED OWNS YOU NIGGA",
    "# The world boutta end tmrw cuz you had sex with loofy with an omni toe in his hand",
    "# Get a load of this faggot https://cdn.discordapp.com/attachments/1292181560598204580/1309552201080770640/Screenshot_2024-11-20_103114.png?ex=6741ff07&is=6740ad87&hm=59c49d7cac72781dea3487d35402d525edc8b2a9669a61e529753b7fea9e6646&",
    "# Im really boutta get to flaming on yo ass my nigga tell me why you built like a retarded drill sargeant that pulled 4 fire alarms and got shot in the thigh 8 times my nigga",
    "# YOU DIED BY DESIRE BTW,",
    "# My nigga dont let me get on yo 'not even bob the builder can fix my face' headass nigga tell me why you pulled down your facemask and someone called you atomic breath",
    "# Im really on yo shit you dumb ass retarded beetle juice looking ass nigga you look like jimmy neutron if he drank monster mixed with gfuel my nigga im on yo shit",
    "# angel owns you,",
    "# Nigga looks like *67 https://cdn.discordapp.com/attachments/1292181560598204580/1309558157722517676/83bb6db510bffa807bf06c1e10333f7c.webp?ex=67420493&is=6740b313&hm=c8b48844559ce8727b2ca647420b712d588eef5cd1c2909ff93661be9ac74b43&",
    "# My nigga tell me why i found you taking a shit behind your local H-E-B you really bout dumb ass shit boy tell me why you look like dory from finding nemo im on yo shit",
    "# YOU DIED BY TIM BTW",
    "# wyd bro https://cdn.discordapp.com/attachments/1292181560598204580/1309551354699841618/Screenshot_2024-11-22_105424.png?ex=6741fe3d&is=6740acbd&hm=e787d0c812aaf27f7573433e4f540a0e6e07de7d6376cc469ce633efb047e8e6&",
    "# Nigga your head looks like a dorito my nigga you got that shit from phineas and ferb tell me why i saw you beating your meat to dora the explora at the middle of the night while saying 'drop the beat' you dumb ass nigga gothic emo ass nigga",
    "# Shut yo dumb ass up nigga tell me why I indian burned your mom in the ankle and i had the bitch saying she was indiana jones my nigga you bout nasty ass shit tell me why i saw you buying faze rug gfuel then washing your face with it nigga",
    "# all mighty push! DATTEBYO🖐️😅",
    "# Nigga look emo asl https://cdn.discordapp.com/attachments/1292181560598204580/1309558158125043824/ab67616d0000b27321645289bebf75acc19ecb65.jpg?ex=67420493&is=6740b313&hm=2587cf19eaeddb032a0cfdbe2e886cca17522fe7b23313c759864d8e05c29c05&",
    "# Boy you dumb like shit im finna make you do a 360 spin yesterday i saw you playing with bricks, yesterday your cousin’s dog had you embraced my nigga even a animal left you in daze you bum ass nigga you really bout dirty ass shit",
    "# Greed,",
    "# put a shirt on ugly nigga https://cdn.discordapp.com/attachments/1292181560598204580/1309558893570949191/hq720.png?ex=67420542&is=6740b3c2&hm=632542739f10894142a316a4ae7e4077dd34ee39c935cb21407cc5e5e7867547&",
    "# dont be like telqr dumbass nigga https://cdn.discordapp.com/attachments/1292181560598204580/1309559214057721896/Screenshot_65.png?ex=6742058f&is=6740b40f&hm=695ef457b37682a45fe57314532afb6f151c7d7d8f895bbdf8e7fdd0d5136b0c&",
    "# Shut up you dumb ass nigga i’ll get on yo shit too my nigga i know you aint trynna talk back to me nigga I’ll slap your tounge back into your mouth my nigga you upside down weird body shaped ass nigga. You built like a snowcone wearing a Yankees jersey my nigga you look like the retarded fro-zone",
    "# you got a pet fish named basketball",
    "# AINT THIS YOU? https://cdn.discordapp.com/attachments/1292181560598204580/1309552139940401293/Screenshot_2024-11-20_202849.png?ex=6741fef8&is=6740ad78&hm=ef60a42a5107bf025a319b63c1c0e9d0cd77fc6c92b58d33eaa2603b712925bf&",
    "# yo sunroof is just a paper plane that you put in yo ass for fun",
    "# YOU DIED BY GREED BTW,",
    "# yo shirt just says bloody hell and theres a knife logo on it",
    "# that was not a whale you saw at the museum, it was just joe rogan in a clown costume",
    "# i am god faggot queer",
    "# Exorcist runs you btw",
    "# DESIRE OWNS YOU NIGGA",
    "# yo uncle said what time is it, and you said its 5.50$ please",
    "# you cant pee without a ghost slapping you on the back of the head and saying no",
    "# Your home FAGGOT https://cdn.discordapp.com/attachments/1292181560598204580/1309552028938277004/Screenshot_2024-09-29_174856.png?ex=6741fedd&is=6740ad5d&hm=3007d98ab39d7e0c53747744d20f7a959f543b7d51e7661db0ea85b5b0218a91&",
    "# you got a fanny pack filled with walking hot dogs in yo room",
    "# everytime you breathe, your nose flips sideways",
    "# YOU DIED BY DESIRE BTW",
    "# you never went to school again after seeing that on your crayon its writen 'kill yourself'",
    "# GREED OWNS YOU NIGGA",
    "# Nigga tried to end it in minecraft wyd bro https://cdn.discordapp.com/attachments/1292181560598204580/1309547410707583108/1900x1900-000000-80-0-0.png?ex=6741fa90&is=6740a910&hm=5a981da34dae1f4f98a43f35156ac52ab3be47e2797674c87c38c1a4625ec580&",
    "# you put a dynamite in your dads car engine and told him to have a great day",
    "# GREED OWNS YOU NIGGA",
    "# you just a happy water bug on a sunday",
    "# you just build like an adonis creed queef machine",
    "# your buttcheeks are just vertical so when you walk down the stairs, they clap for no reason at all",
    "# Pick your dead ass father up NIGGA https://cdn.discordapp.com/attachments/1292181560598204580/1309551502066450592/Screenshot_2024-11-04_185506.png?ex=6741fe60&is=6740ace0&hm=faf884930b142166e7cd80a6fc27e920d7acfe197a94957a85ea72c38a3aea32&,",
    "# yo uncle asked you for chicken strips and you made a chicken strip",
    "# you did a cartwheel and yo shoes knocked yo uncle out",
    "# nigga you play baseball with a vibrator",
    "# nigga yo uncle cant look at you without a tesla beating its dick in a wendys bathroom to thizzkid giving a looks maxing course to a beaver on halloween",
    "# you asked yo dad if he loved you and he pulled a hammer out",
    "# look at you trya be a thug https://cdn.discordapp.com/attachments/1292181560598204580/1309551492805427251/Screenshot_2024-11-05_045012.png?ex=6741fe5e&is=6740acde&hm=c6a0bee875361248950488395f60779f4aa36c4d78193a20325130053dd9bbca&",
    "# GREED OWNS YOU NIGGA,",
    "# you left the barber with a fresh cut and a missing arm",
    "# you sound like someone threw a bomb in yo mouth", 
    "# you sound like me after i drink 2 litters of pepsi without burping",
    "# GREED OWNS YOU NIGGA",
    "# wyd bro https://cdn.discordapp.com/attachments/1292181560598204580/1309551546454900816/Screenshot_2024-11-04_143926.png?ex=6741fe6a&is=6740acea&hm=f72bba1f297ba2e5a3d3ee184d48cac15f8f8eaa8fbad9515764c8460edae097&",
    "# you put a condom on to protect yourself in a fight",
    "# you did a thumb war against the easter bunny and lost yo thumb",
    "# nigga yo uncle lost his dick cuz randy orton overtalked him with a chair",
    "# DESIRE OWNS YOU NIGGA",
    "# Nigga yo clothes stink cuz ren and stimpy trickshotted yo washing machine",
    "# You lost a 4million dollar bet cuz yo mom can’t pay her taxes in time",
    "# get your tranny ass on nigga https://cdn.discordapp.com/attachments/1292181560598204580/1309551857227530240/Screenshot_2024-10-14_164204.png?ex=6741feb5&is=6740ad35&hm=9059dcbffed3c28e92ebea18b447ad079304848b701fad7e0a5a258c4ce6683c&",
    "# You put yo tooth under the pillow and woke up with a chopped off head and no money"
    "# You’ve never been the same ever since you told your dad you loved him cuz you arrived the next day at school with a black eye",
    "# You got pressed by a dolphin listening to heavy metal while doing martial arts",
    "# DONT be like this nigga https://cdn.discordapp.com/attachments/1292181560598204580/1309554609467031632/Screenshot_2024-08-07_024247.png?ex=67420145&is=6740afc5&hm=88122e71e83e4624a4d2349dd01d4c7b908a51646efb18c32e19667f4ec45ba5&",
    "# SLUMP OWNS YOU NIGGA",
    "# The only reason that This nigga is on hots right now is cuz he can’t go in the bathroom without a leprechaun spying on him",
    "# This nigga put an AirTag in his food so he wouldn’t get it stolen fat ass nigga",
    "# https://cdn.discordapp.com/attachments/1290454153977659493/1290633909503262730/attachment-2.gif?ex=6741b9fe&is=6740687e&hm=4e390064ae734a2859eaef22678036296b2d4996e37f6ce41313c2cb5fd1b280&",
    "# You gotta superglue yo haircut on yo head daily or it will fall off",
    "# after you beat someones ass, you gave him a handshake",       
    "# YOU DIED BY GREED BTW",
    "# COME DIE IN .GG/DANG",
    "# aint this you? https://cdn.discordapp.com/attachments/1292181560598204580/1309545808613605537/big-brumda-brumbda.gif?ex=6741f912&is=6740a792&hm=b50149661d70e04e4f189038ccab43809440fd6b9721b16cbca72907c27d2f97&",  
    ]
# So fucking annoying and long for no reason

@bot.command()
async def kill(ctx, user: discord.User):
    await ctx.message.delete()

    global press_task
    async def press_loop():
        while True:
            await ctx.send(random.choice(presstext))
            await ctx.send(user.mention)


    press_task = bot.loop.create_task(press_loop())





@bot.command()
async def die(ctx):
    await ctx.message.delete()
    global press_task
    if press_task:
        press_task.cancel()
        press_task = None
        await ctx.send("```[+] victim neutralized .```")
    else:
        await ctx.send("```[+] kill is already disabled dumbass nigga.```")

# Perish with the domain of desire..
bot.run(t973, bot=False)